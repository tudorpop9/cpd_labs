
public interface Response extends Message {
    ResponseType getType();
}
