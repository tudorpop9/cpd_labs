public interface Request extends Message {

    RequestType getType();

}
