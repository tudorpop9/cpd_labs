package ro.utcn.cpd.franklin.enums;

/**
 * Specifies the message direction.
 * <p/>
 * User: Tamas
 * Date: 05/01/14
 * Time: 15:09
 */
public enum MessageDirection {
    LEFT,
    RIGHT
}
