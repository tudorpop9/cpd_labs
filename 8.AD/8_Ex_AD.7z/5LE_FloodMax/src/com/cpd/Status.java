package com.cpd;

public enum Status {
    UNKNOWN, LEADER, NONLEADER;
}
