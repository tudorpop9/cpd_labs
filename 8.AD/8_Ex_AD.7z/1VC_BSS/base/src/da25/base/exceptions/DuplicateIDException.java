package da25.base.exceptions;

public class DuplicateIDException extends Exception {
	private static final long serialVersionUID = 1L;

}
